# UltraVNC
UltraVNC Server and UltraVNC Viewer

Required compilers

Visual Studio 2017 or 2019

nasm assembler compiler (https://www.nasm.us/)


Load the project files vncviewer_vs2017.sln and winvncVS2017.sln to build server or viewer.
